
rootProject.name = "RockPaperScissors"

